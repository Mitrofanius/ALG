#include <cstdio>
#include <stdio.h>
#include <cstdlib>
#include <algorithm>
#include <iostream>
#include <vector>
#define LOG(a) std::cout << a << "\n"

struct Movie {
    int cinema_num;
    int start;
    int end;
    int best;
    int time;
};

struct Parameters{
    int max_movies;
    int n_cinemas, movie_time;
    int * travel_times;
    std::vector<Movie*> movies_vect;
};

void get_input(Parameters &p){
    int n = 0;
    scanf("%d %d", &p.n_cinemas, &p.movie_time);
    p.travel_times = new int[p.n_cinemas * p.n_cinemas];
    for (int i = 0; i < p.n_cinemas * p.n_cinemas; i++)
    {
        scanf("%d", &p.travel_times[i]);
    }

    for (int i = 0; i < p.n_cinemas; i++)
    {
        scanf("%d", &n);
        for (int j = 0; j < n; j++)
        {
            Movie *mov = new Movie();
            scanf("%d ", &mov->start);
            mov->end = mov->start + p.movie_time;
            mov->cinema_num = i;
            mov->best = 1;
            mov->time = 0;
            p.movies_vect.push_back(mov);
        }
    }
    std::sort(p.movies_vect.begin(), p.movies_vect.end(), [](Movie *a, Movie *b){return a->start < b->start;});
}

void print_ans(Parameters &p){
    int max_movies = 0;
    int best_time = 0;
    int last_max = 0;
    for (Movie *m : p.movies_vect){
        if (m->best > max_movies){
            max_movies = m->best;
        }
        if (m->time > best_time && m->best > last_max){
            best_time = m->time;
        }
        else if (m->time < best_time  && m->best == last_max){
            best_time = m->time;
        }
        last_max = max_movies;
    }

    printf("%d %d\n", max_movies, best_time);
}

void count_it(Parameters &p){
    int time_needed = 0;
    int max_movies = 0;
    int best_time = 0;
    int last_max = 0;


    Movie *to, *from;
    for (int i = 1; i < p.movies_vect.size(); i++)
    {
        to = p.movies_vect.at(i);
        for (int j = i - 1; j >= 0; j--)
        {
            from = p.movies_vect.at(j);
            time_needed = p.travel_times[p.n_cinemas * to->cinema_num + from->cinema_num];
            if (to->best > from->best + 150) break;
            if (from->end + time_needed <= to->start){
                if (from->best + 1 > to->best){
                    to->best = from->best + 1;
                    to->time = from->time + time_needed;
                }
                else if ((from->best + 1 == to->best) && (from->time + time_needed < to->time)){
                    to->time = from->time + time_needed;
                }
            }
        }

        if (to->best > max_movies){
            max_movies = to->best;
        }
        if (to->time > best_time && to->best > last_max){
            best_time = to->time;
        }
        else if (to->time < best_time  && to->best == last_max){
            best_time = to->time;
        }
        last_max = max_movies;

    }

    printf("%d %d\n", max_movies, best_time);

    // print_ans(p);
}

int main(int argc, char * argv[]){
    Parameters params;
    get_input(params);

    // LOG(params.n_cinemas);
    // LOG(params.movie_time);

    // for (int i = 0; i < params.n_cinemas * params.n_cinemas; i++)
    // {
    //     printf("%d ", params.travel_times[i]);
    // }
    // LOG(" ");


    // for (int i = 0; i < params.movies_vect.size(); i++){
    //     LOG(params.movies_vect.at(i)->start << " " << params.movies_vect.at(i)->end);
    // }

    count_it(params);
    
    // for (int i = 0; i < params.movies_vect.size(); i++){
    //     LOG(params.movies_vect.at(i)->start << " " << params.movies_vect.at(i)->best);
    // }
    for (int i = 0; i < params.movies_vect.size(); i++)
    {
        delete params.movies_vect.at(i);
    }
    

    delete[] params.travel_times;
    return 0;
}